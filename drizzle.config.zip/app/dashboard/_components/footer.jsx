


// import React from 'react';



// const Footer = () => {
//   return (
//     <footer className="flex justify-end bg-gray-900 text-white py-4 mt-10 ">
//       <div className="container text-center">
//         <p className="text-sm">&copy; {new Date().getFullYear()} Your Company Name. All rights reserved.</p>
//       </div>
//     </footer>
//   );
// };

// export default Footer;


